const User = require("../model/users");
const mongoose = require("mongoose");
const express = require("express");
const app = express();
const cors = require("cors");

app.use(cors());
app.use(express.json({ limit: "200mb" }));
app.use(express.static("./build"));
app.use(express.static("./uploads"));
app.use(express.urlencoded({ limit: "200md", extended: true }));
// Model Import for chat and blogs post etc

//--------------.ENV CONFIG------------------//
const MONGO_URI =
  process.env.MONGO_URI ||
  "mongodb+srv://usmanlatif762:myproject@cluster0.sqmj7dr.mongodb.net/?retryWrites=true&w=majority";

//------------DB CONNECTION---------------//

mongoose
  .connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log("DB connected");
  })
  .catch((error) => {
    console.log("DB not connected", error);
  });
// mongoose.connect(
//   MONGO_URI,
//   { useNewUrlParser: true, useUniFiedTopolgy: true },
//   (err, connection) => {
//     console.log(err || connection);
//   }

// useNewUrlParser option enables the use of the new URL parser, //
// useUnifiedTopology enables the use of the new Server Discovery and Monitoring engine, //

//--------- NOW MAKING API ROUTES-----------------------//

//-----------Routes-----------------//

app.get("/", async (req, res) => {
  const user = await User.find({});
  res.send(user);
});

//--------------------SIGN UP ROUTE--------------------//
app.post("/singup", async (req, res) => {
  const {
    firsname,
    lastname,
    email,
    phonenumber,
    address,
    password,
    confirmpassword,
  } = req.body;
  try {
    const user = await User.findOne({ email });
    if (user) {
      res.send({ success: false, message: "This email is already exist" });
    } else {
      const newUser = new User({
        firsname,
        lastname,
        email,
        phonenumber,
        address,
        password,
        confirmpassword,
      });
      await newUser.save();
      res.send({ success: true, message: "User Registered" });
    }
  } catch (error) {
    console.log(error);
    res.send({ success: false, message: error.message });
  }
});

//----------LOGIN ROUTE----------//
app.post("/login", async (req, res) => {
  try {
    let user = await User.findOne({ email: req.body.email });
    if (user && user.password === req.body.password) {
      res.send({ success: true, message: `Welcome ${user.firstname}`, user });
    } else {
      res.send({ success: false, message: "User not found", user });
    }
  } catch (error) {
    console.log(error);
    res.send({ success: false, message: error.message });
  }
});

//-----------------RESET ROUTE--------------//
app.post("/reset", async (req, res) => {
  const { email, password } = req.body;
  console.log(email, password, " email and password");
  try {
    const user = await User.find({ email: email });
    if (user) {
      await User.updateOne({ email: email }, { password: password });
      res.send({ success: true, message: "password successfully reset" });
    } else {
      res.send({ success: false, message: "email is not registered" });
    }
  } catch (error) {
    res.send({ success: false, message: error.message });
  }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`server is chling on port ${PORT}`);
});
