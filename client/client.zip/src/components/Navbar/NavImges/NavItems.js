const NavItems = [
    {
        title:"Home",
        Link:"/"
    },
    {
        title:"Menu",
        Link:"menu"
    },
    {
        title:"About",
        Link:"about"
    },
    {
        title:"Contact",
        Link:"contact"
    },
    // {
    //     title:"Book Table",
    //     Link:"book-table"
    // },
]

export default NavItems;