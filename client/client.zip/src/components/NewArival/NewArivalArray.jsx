import ONE from "./NewArivalImage/one.png";
import TWO from "./NewArivalImage/two.png";
import THREE from "./NewArivalImage/three.png";
const NewArivalArray = [
  {
    img: ONE,
    title: "Hoodies & Sweetshirt",
    subtitle: "Explore Now!",
  },
  {
    img: TWO,
    title: "Coats & Parkas",
    subtitle: "Explore Now!",
  },
  {
    img: THREE,
    title: "Tees & T-Shirt",
    subtitle: "Explore Now!",
  },
];
export default NewArivalArray;
