import ONE from "./YoungsImage/one.png";
import TWO from "./YoungsImage/two.png";
const YoungsArray = [
  {
    IMG: ONE,
    title: "Trending on instagram",
    subtitle: "Explore Now!",
  },
  {
    IMG: TWO,
    title: "All Under $40",
    subtitle: "Explore Now!",
  },
];
export default YoungsArray;
